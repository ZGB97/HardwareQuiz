const prompt = require("prompt-sync")();  //const cannot change. const is used to declare a varible. This loads module "require("prompt-sync")".You then get access to it in the prompt variable
//now you can use the prompt variable to grab input.

console.log("Welcome to the Computer Hardware Quiz!");

let correctAnswers = 0;  //THIS allows you to go into if statements and get if they got it correct.
const totalQuestions = 3;  //number of questions is 3

//***const value = prompt("Enter something:  ");  ***  //gives access to what user type.  Const value is declaring a variable name value. A variable gives us access to a piece of data. Which is a string in this case
                                                       //Data Types are diffirent peices of information we can store in are program such as numbers,boolean value,true/false, strings,arrays.
//" prompt("Enter something:  ");"                     //Is a function. A function gives us a string  which is a data type in are program. We store that in
// the variable VALUE. Which IS BELOW. Then we access  what we stored inside of that variables by using the variable name. String is inside quotiention

//*****console.log(value);***

//****let value = prompt("Enter something:  ");***   //let is opposite of const because it can change.

const answer1 = prompt("What is the brain of the computer ");
const correctAnswer1 = "CPU";                                //Variable = answer1 and correct_answer1. Next we would use a IF Statement. Which allows us to evaluate a condition and see if its true.

if (answer1.toUpperCase() === correctAnswer1) {                             //(answer1 === correct_answer1)   is the condition that needs to be evaulated true or false
    console.log("You are Correct!");                                         //toUpperCase() is a method . That helps  when a user puts (cpu, CPU, CpU) for the answer.
    correctAnswers++;       //or correctAnswer 1;
} else{
    console.log("You got it wrong...!");
}

const answer2 = prompt("True or false ? When you save a file on a computer. It is permanently saved on the Hard Drive ");
const correctAnswer2 = "TRUE";

if (answer2.toUpperCase() === correctAnswer2) {
    console.log("You are Correct!");
    correctAnswers++;
} else {
    console.log("You got it wrong.. ");
}

const answer3 = prompt("What is the reccomend amount of RAM in 2023? ");
const correctAnswer3 = "16GB";

if (answer3.toUpperCase() === correctAnswer3) {
    console.log("You are correct!");
    correctAnswers++;                             //also will tell us the answer we got correct at the end of the program.
} else {
    console.log("You got it wrong.. ");
}


//Now we have to keep track of correct  answers. By getting a variable to store answer correct and display it.
//go to the top of program before the questionst line 6.  LIGHT BLUE VARIABLES

//Tell user how many answer they got right

console.log("You got ", correctAnswers, "questions correct!");


//we can give user a percentage or grade. Created variable line 7

//console.log("You score was", (correctAnswers/totalQuestions)* 100, "percent!");   //this would  make the percentage be 66.6666, 33.3333, etc

//this would be cleaner/better for line 59 showing are percent to user

const percent = Math.round((correctAnswers/totalQuestions)*100);

console.log("You scored a", percent,"percent!");